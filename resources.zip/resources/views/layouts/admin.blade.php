<!DOCTYPE html>
<html>
<head>
    <title>ProTrack</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<div class="container-fluid">

    <div class="row">

        <!-- Sidebar -->
        <div class="col-md-2 bg-dark text-white vh-100">

            <h3 class="mt-3">PROTRACK</h3>

            <hr>

            <ul class="nav flex-column">

                <li class="nav-item">
                    <a href="/admin" class="nav-link text-white">
                        Dashboard
                    </a>
                </li>

                <li class="nav-item">
                    <a href="/customers" class="nav-link text-white">
                        Customers
                    </a>
                </li>

                <li class="nav-item">
                    <a href="/spks" class="nav-link text-white">
                        SPK
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-white" href="/import-xml">
                        Import XML
                    </a>
                </li>

                <li class="nav-item">
                    <a href="/progress-logs" class="nav-link text-white">
                        Progress Produksi
                    </a>
                </li>

                <li class="nav-item">
                    <a href="/notifications" class="nav-link text-white">
                        Notifikasi
                    </a>
                </li>

                <li class="nav-item mt-3">
                    <a href="/logout" class="nav-link text-danger">
                        Logout
                    </a>
                </li>

            </ul>

        </div>

        <!-- Content -->
        <div class="col-md-10 p-4">

            @yield('content')

        </div>

    </div>

</div>

</body>
</html>